---
name: Bug report
about: Something doesn't work
labels: bug
---

**Minecraft / Fabric Loader / Fabric API versions**

**What happened**

**What you expected**

**`logs/latest.log`** (attach the file, or paste the lines around the error / crash report)

**Does it happen with only Fabric API + this mod installed?**
