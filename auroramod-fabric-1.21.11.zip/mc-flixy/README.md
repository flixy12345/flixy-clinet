# Aurora Sky + Center HUD + Money Tracker

[![build](https://github.com/flixy12345/mc-flixy/actions/workflows/build.yml/badge.svg)](https://github.com/flixy12345/mc-flixy/actions/workflows/build.yml)

A client-side **Fabric** mod for **Minecraft 1.21.11**.

- **Five night-sky styles** (Aurora, Iris, Galaxy, Velvet, Silver), drawn with custom render pipelines so
  terrain covers them correctly. Aurora has color presets, hue shift, saturation and custom colors.
- **Smooth HUD slide** - press **V** and the hotbar, health, hunger, armor, XP bar and item name glide to
  just under the crosshair. Press again to glide back. The camera never moves.
- **DonutSMP money tracker** in a black bubble: your starting balance when you join, everything you
  earn or lose after it, and a day-trading style line chart (green above your start, red below).
- **FPS counter and keystrokes** in the same bubble style.
- **Launcher-style menu** (press **K**): a black window with a clickable menu down the side
  (Tracker, Money, Sky, Aurora, Motion, Colors, HUD, Display, Modules), with live preview.

## Install
1. Install [Fabric Loader](https://fabricmc.net/use/installer/) 0.18.1+ for Minecraft 1.21.11 and Java 21.
2. Put [Fabric API](https://modrinth.com/mod/fabric-api) (0.141.x for 1.21.11) and `auroramod-*.jar`
   in your `mods` folder.

## Keys (rebind under Controls > Aurora Mod)
| Key | Action |
| --- | --- |
| `V` | Slide the HUD to the center / back (or hold, if "Hold key" is on) |
| `K` | Open the menu |
| unbound | Reset the money session |

## DonutSMP money tracker
Reads the "Money" line of the sidebar scoreboard that the server already sends you. Each time you join,
the balance you join with becomes your **starting balance**, and every later gain or loss is added to or
subtracted from it. Change the chart range (Session / 1H / Day / Week / All) on the **Tracker** page.
Chart history is saved in `config/auroramod-history.json`.

- It only runs on servers whose address contains `donutsmp` (changeable on the **Money** page).
- It is passive: it only reads the scoreboard. **There is no network code in this mod at all.**
- The scoreboard shows abbreviated numbers (like `1.25M`), so changes smaller than that rounding can't be seen.
- Every balance change counts, including `/pay`, shop purchases, `/sell` and auction sales.
- If the Money page says "Waiting for a scoreboard line...", set **Scoreboard line** to the word the
  sidebar shows next to your balance.

Settings are saved to `config/auroramod.json`.

## Build from source
Requires JDK 21 and Gradle 9.2.1 (or a wrapper from <https://fabricmc.net/develop>):

```sh
gradle build
```

The jar is written to `build/libs/auroramod-<version>.jar`. This project uses Mojang's official mappings
and has no mixins.

## License
[MIT](LICENSE)
