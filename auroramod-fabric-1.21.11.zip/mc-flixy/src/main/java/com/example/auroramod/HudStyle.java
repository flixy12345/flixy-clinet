package com.example.auroramod;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Shared look: black rounded bubbles, small grey labels, bold values, green/red accents. */
public final class HudStyle {
    // ARGB. The alpha byte must be 0xFF on text colors or the text is invisible in 1.21.6+.
    public static final int GREY = 0xFF8A8F98, WHITE = 0xFFFFFFFF, GREEN = 0xFF4ADE80, RED = 0xFFF87171,
            GOLD = 0xFFFFD166, DIVIDER = 0x22FFFFFF;

    private HudStyle() {}

    /** Filled rectangle with rounded corners, built from plain fills. */
    public static void roundRect(GuiGraphics g, int x, int y, int w, int h, int r, int color) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(Math.max(0.0, r * r - dy * dy)));
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            g.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
        g.fill(x, y + r, x + w, y + h - r, color);
    }

    /** Black bubble with a faint outline. bgAlpha is 0..255. */
    public static void panel(GuiGraphics g, int x, int y, int w, int h, int bgAlpha) {
        if (bgAlpha <= 0) return;
        int border = (Math.min(0x30, bgAlpha / 4) << 24) | 0xFFFFFF;
        roundRect(g, x - 1, y - 1, w + 2, h + 2, 9, border);
        roundRect(g, x, y, w, h, 8, bgAlpha << 24);
    }

    private static Component comp(String s, boolean bold) {
        return bold ? Component.literal(s).withStyle(ChatFormatting.BOLD) : Component.literal(s);
    }

    public static int width(Font font, String s, float scale, boolean bold) {
        return (int) Math.ceil(font.width(comp(s, bold)) * scale);
    }

    /** Draws text at (x, y) in the current local coordinates, scaled. */
    public static void text(GuiGraphics g, Font font, String s, float x, float y, int color, float scale, boolean bold) {
        g.pose().pushMatrix();
        g.pose().translate(x, y);
        g.pose().scale(scale, scale);
        g.drawString(font, comp(s, bold), 0, 0, color);
        g.pose().popMatrix();
    }
}
