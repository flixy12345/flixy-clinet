package com.example.auroramod;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Procedural night-sky pieces: stars, nebula clouds, lightning web, ringed planet, black hole, tint. */
final class SkyScene {
    static final float TAU = (float) (Math.PI * 2.0);
    private static boolean inited = false;

    private SkyScene() {}

    private static float sin(float v) { return (float) Math.sin(v); }
    private static float cos(float v) { return (float) Math.cos(v); }
    private static float clamp(float v, float lo, float hi) { return v < lo ? lo : Math.min(v, hi); }
    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }

    static void init() {
        if (inited) return;
        inited = true;
        Random r = new Random(77L);
        genStars(r);
        genNebula(r);
        genLightning();
    }

    // =========================================================== stars

    static final int MAX_STARS = 4400;
    private static float[] sx, sy, sz, srx, srz, sux, suy, suz, ssize, sbright, sph, scr, scg, scb;

    private static void genStars(Random r) {
        sx = new float[MAX_STARS]; sy = new float[MAX_STARS]; sz = new float[MAX_STARS];
        srx = new float[MAX_STARS]; srz = new float[MAX_STARS];
        sux = new float[MAX_STARS]; suy = new float[MAX_STARS]; suz = new float[MAX_STARS];
        ssize = new float[MAX_STARS]; sbright = new float[MAX_STARS]; sph = new float[MAX_STARS];
        scr = new float[MAX_STARS]; scg = new float[MAX_STARS]; scb = new float[MAX_STARS];
        float[][] pal = {{1f, 1f, 1f}, {0.85f, 0.9f, 1f}, {1f, 0.92f, 0.8f}, {0.85f, 0.75f, 1f}, {0.95f, 0.8f, 1f}};
        for (int i = 0; i < MAX_STARS; i++) {
            float y = -0.05f + 1.05f * r.nextFloat();
            float a = r.nextFloat() * TAU;
            float rr = (float) Math.sqrt(Math.max(0f, 1f - y * y));
            sx[i] = rr * cos(a); sy[i] = y; sz[i] = rr * sin(a);
            srx[i] = -sin(a); srz[i] = cos(a);
            // up = cross(direction, right) with right = (srx, 0, srz)
            sux[i] = sy[i] * srz[i];
            suy[i] = sz[i] * srx[i] - sx[i] * srz[i];
            suz[i] = -sy[i] * srx[i];
            float q = r.nextFloat();
            ssize[i] = 0.0013f + 0.0032f * q * q * q;
            float br = r.nextFloat();
            sbright[i] = 0.35f + 0.65f * br * br;
            sph[i] = r.nextFloat() * TAU;
            float[] pc = pal[r.nextInt(pal.length)];
            scr[i] = pc[0]; scg[i] = pc[1]; scb[i] = pc[2];
        }
    }

    static void stars(SkyBatch b, int count, float t, float strength, float rot) {
        count = Math.min(count, MAX_STARS);
        float c = cos(rot), s = sin(rot);
        for (int i = 0; i < count; i++) {
            float dy = sy[i];
            if (dy < -0.04f) continue;
            float dx = sx[i] * c - sz[i] * s, dz = sx[i] * s + sz[i] * c;
            float rx = srx[i] * c - srz[i] * s, rz = srx[i] * s + srz[i] * c;
            float ux = sux[i] * c - suz[i] * s, uz = sux[i] * s + suz[i] * c, uy = suy[i];
            float k = ssize[i];
            float a = Math.min(1f, sbright[i] * (0.72f + 0.28f * sin(t * 2.2f + sph[i])) * strength);
            float r0 = scr[i], g0 = scg[i], b0 = scb[i];
            b.v(dx - (rx + ux) * k, dy - uy * k, dz - (rz + uz) * k, r0, g0, b0, a);
            b.v(dx + (rx - ux) * k, dy - uy * k, dz + (rz - uz) * k, r0, g0, b0, a);
            b.v(dx + (rx + ux) * k, dy + uy * k, dz + (rz + uz) * k, r0, g0, b0, a);
            b.v(dx - (rx - ux) * k, dy + uy * k, dz - (rz - uz) * k, r0, g0, b0, a);
        }
    }

    // =========================================================== nebula

    private static final int BLOBS = 18;
    private static float[] nbx, nby, nbz, nrx, nrz, nux, nuy, nuz, nsize, nalpha, nph;
    private static float[][] ncol;

    private static void genNebula(Random r) {
        nbx = new float[BLOBS]; nby = new float[BLOBS]; nbz = new float[BLOBS];
        nrx = new float[BLOBS]; nrz = new float[BLOBS];
        nux = new float[BLOBS]; nuy = new float[BLOBS]; nuz = new float[BLOBS];
        nsize = new float[BLOBS]; nalpha = new float[BLOBS]; nph = new float[BLOBS];
        ncol = new float[BLOBS][];
        float[][] pal = {{0.45f, 0.12f, 0.90f}, {0.65f, 0.20f, 0.95f}, {0.30f, 0.10f, 0.70f}, {0.85f, 0.35f, 0.95f}};
        for (int i = 0; i < BLOBS; i++) {
            float y = 0.02f + 0.95f * r.nextFloat();
            float a = r.nextFloat() * TAU;
            float rr = (float) Math.sqrt(Math.max(0f, 1f - y * y));
            nbx[i] = rr * cos(a); nby[i] = y; nbz[i] = rr * sin(a);
            nrx[i] = -sin(a); nrz[i] = cos(a);
            nux[i] = nby[i] * nrz[i];
            nuy[i] = nbz[i] * nrx[i] - nbx[i] * nrz[i];
            nuz[i] = -nby[i] * nrx[i];
            nsize[i] = 0.16f + 0.30f * r.nextFloat();
            nalpha[i] = 0.10f + 0.12f * r.nextFloat();
            nph[i] = r.nextFloat() * TAU;
            ncol[i] = pal[r.nextInt(pal.length)];
        }
    }

    static void nebula(SkyBatch b, float t, float strength, float rot) {
        final int g = 6;
        float c = cos(rot), s = sin(rot);
        for (int i = 0; i < BLOBS; i++) {
            for (int gx = 0; gx < g; gx++) {
                for (int gy = 0; gy < g; gy++) {
                    nebVertex(b, i, gx, gy, g, c, s, t, strength);
                    nebVertex(b, i, gx + 1, gy, g, c, s, t, strength);
                    nebVertex(b, i, gx + 1, gy + 1, g, c, s, t, strength);
                    nebVertex(b, i, gx, gy + 1, g, c, s, t, strength);
                }
            }
        }
    }

    private static void nebVertex(SkyBatch b, int i, int gx, int gy, int g, float c, float s, float t, float strength) {
        float uu = (float) gx / g * 2f - 1f, vv = (float) gy / g * 2f - 1f;
        float rad = (float) Math.sqrt(uu * uu + vv * vv);
        float fall = 1f - Math.min(1f, rad);
        fall = fall * fall * (3f - 2f * fall);
        float cloud = 0.6f + 0.4f * sin(uu * 5.3f + nph[i] + t * 0.05f) * sin(vv * 4.7f - nph[i] * 1.3f);
        float a = Math.min(1f, nalpha[i] * fall * cloud * strength);
        float u = uu * nsize[i], v = vv * nsize[i];
        float x0 = nbx[i] + nrx[i] * u + nux[i] * v;
        float y = nby[i] + nuy[i] * v;
        float z0 = nbz[i] + nrz[i] * u + nuz[i] * v;
        b.v(x0 * c - z0 * s, y, x0 * s + z0 * c, ncol[i][0], ncol[i][1], ncol[i][2], a);
    }

    // =========================================================== lightning web

    private static final float STEP = 0.021f;
    private static final float LAMP = 0.0022f;
    private static final int MAX_LINE = 140;
    private static float[] lpx, lpy, lpz, lsx, lsy, lsz, lWidth, lPhase;
    private static int[] lStart, lLen;
    private static int lineCount;
    private static final float[] dxs = new float[MAX_LINE], dys = new float[MAX_LINE], dzs = new float[MAX_LINE];

    private static void genLightning() {
        Random r = new Random(4242L);
        List<float[]> lines = new ArrayList<>();
        List<Float> widths = new ArrayList<>();
        for (int n = 0; n < 11; n++) {
            float y = 0.05f + 0.93f * r.nextFloat();
            float a = r.nextFloat() * TAU;
            float rr = (float) Math.sqrt(Math.max(0f, 1f - y * y));
            float px = rr * cos(a), pz = rr * sin(a);
            float rx = -sin(a), rz = cos(a);
            float ux = y * rz, uy = pz * rx - px * rz, uz = -y * rx;
            float h = r.nextFloat() * TAU;
            float tx = rx * cos(h) + ux * sin(h);
            float ty = uy * sin(h);
            float tz = rz * cos(h) + uz * sin(h);
            walk(r, lines, widths, px, y, pz, tx, ty, tz, 55 + r.nextInt(45), 1f, 0);
        }
        lineCount = lines.size();
        int total = 0;
        for (float[] l : lines) total += l.length / 3;
        lpx = new float[total]; lpy = new float[total]; lpz = new float[total];
        lsx = new float[total]; lsy = new float[total]; lsz = new float[total];
        lStart = new int[lineCount]; lLen = new int[lineCount];
        lWidth = new float[lineCount]; lPhase = new float[lineCount];
        int k = 0;
        for (int L = 0; L < lineCount; L++) {
            float[] pts = lines.get(L);
            int len = pts.length / 3;
            lStart[L] = k; lLen[L] = len; lWidth[L] = widths.get(L); lPhase[L] = r.nextFloat() * TAU;
            for (int i = 0; i < len; i++) {
                lpx[k + i] = pts[3 * i]; lpy[k + i] = pts[3 * i + 1]; lpz[k + i] = pts[3 * i + 2];
            }
            for (int i = 0; i < len; i++) {
                int a = i < len - 1 ? i : i - 1;
                int bb = a + 1;
                float tx = lpx[k + bb] - lpx[k + a], ty = lpy[k + bb] - lpy[k + a], tz = lpz[k + bb] - lpz[k + a];
                float px = lpx[k + i], py = lpy[k + i], pz = lpz[k + i];
                float cx = py * tz - pz * ty, cy = pz * tx - px * tz, cz = px * ty - py * tx;
                float inv = 1f / Math.max(1e-6f, (float) Math.sqrt(cx * cx + cy * cy + cz * cz));
                lsx[k + i] = cx * inv; lsy[k + i] = cy * inv; lsz[k + i] = cz * inv;
            }
            k += len;
        }
    }

    private static void walk(Random r, List<float[]> lines, List<Float> widths,
                             float px, float py, float pz, float tx, float ty, float tz,
                             int steps, float width, int depth) {
        steps = Math.min(steps, MAX_LINE - 2);
        float[] pts = new float[3 * (steps + 1)];
        pts[0] = px; pts[1] = py; pts[2] = pz;
        for (int i = 1; i <= steps; i++) {
            float ang = (r.nextFloat() - 0.5f) * 0.9f;
            float cx = py * tz - pz * ty, cy = pz * tx - px * tz, cz = px * ty - py * tx;
            float ca = cos(ang), sa = sin(ang);
            tx = tx * ca + cx * sa; ty = ty * ca + cy * sa; tz = tz * ca + cz * sa;
            float nx = px + tx * STEP, ny = py + ty * STEP, nz = pz + tz * STEP;
            float inv = 1f / (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
            px = nx * inv; py = ny * inv; pz = nz * inv;
            float d = tx * px + ty * py + tz * pz;
            tx -= px * d; ty -= py * d; tz -= pz * d;
            float il = 1f / Math.max(1e-6f, (float) Math.sqrt(tx * tx + ty * ty + tz * tz));
            tx *= il; ty *= il; tz *= il;
            pts[3 * i] = px; pts[3 * i + 1] = py; pts[3 * i + 2] = pz;
            if (depth < 2 && r.nextFloat() < 0.06f) {
                float bang = (r.nextBoolean() ? 1f : -1f) * (0.35f + 0.8f * r.nextFloat());
                float bx = py * tz - pz * ty, by = pz * tx - px * tz, bz = px * ty - py * tx;
                float cb = cos(bang), sb = sin(bang);
                walk(r, lines, widths, px, py, pz,
                        tx * cb + bx * sb, ty * cb + by * sb, tz * cb + bz * sb,
                        10 + r.nextInt(20), width * 0.62f, depth + 1);
            }
        }
        lines.add(pts);
        widths.add(width);
    }

    static void lightning(SkyBatch b, float t, float strength, float amount,
                          float hr, float hg, float hb, float cr, float cg, float cb) {
        int n = Math.min(lineCount, Math.round(lineCount * clamp(amount, 0f, 1.5f)));
        for (int L = 0; L < n; L++) {
            int st = lStart[L], len = lLen[L];
            float w = lWidth[L];
            float pulse = 0.5f + 0.5f * sin(t * 1.6f + lPhase[L]);
            float flash = 0.40f + 0.60f * pulse * pulse * pulse;
            for (int i = 0; i < len; i++) {
                int k = st + i;
                float d = LAMP * (sin(t * 3.1f + i * 0.9f + lPhase[L]) + 0.6f * sin(t * 7.3f + i * 1.7f - lPhase[L]));
                dxs[i] = lpx[k] + lsx[k] * d;
                dys[i] = lpy[k] + lsy[k] * d;
                dzs[i] = lpz[k] + lsz[k] * d;
            }
            for (int i = 0; i < len - 1; i++) {
                if (dys[i] < -0.03f && dys[i + 1] < -0.03f) continue;
                float t0 = Math.min(1f, Math.min(i, len - 1 - i) / 5f);
                float t1 = Math.min(1f, Math.min(i + 1, len - 2 - i) / 5f);
                float base = flash * strength;
                ribbon(b, st, i, 0.0065f * w, hr, hg, hb, Math.min(1f, 0.17f * base * t0), Math.min(1f, 0.17f * base * t1));
                ribbon(b, st, i, 0.0015f * w, cr, cg, cb, Math.min(1f, 0.95f * base * t0), Math.min(1f, 0.95f * base * t1));
            }
        }
    }

    private static void ribbon(SkyBatch b, int st, int i, float w, float r, float g, float bl, float a0, float a1) {
        int k0 = st + i, k1 = st + i + 1;
        b.v(dxs[i] - lsx[k0] * w, dys[i] - lsy[k0] * w, dzs[i] - lsz[k0] * w, r, g, bl, a0);
        b.v(dxs[i] + lsx[k0] * w, dys[i] + lsy[k0] * w, dzs[i] + lsz[k0] * w, r, g, bl, a0);
        b.v(dxs[i + 1] + lsx[k1] * w, dys[i + 1] + lsy[k1] * w, dzs[i + 1] + lsz[k1] * w, r, g, bl, a1);
        b.v(dxs[i + 1] - lsx[k1] * w, dys[i + 1] - lsy[k1] * w, dzs[i + 1] - lsz[k1] * w, r, g, bl, a1);
    }

    // =========================================================== tint dome

    static void tint(SkyBatch b, float r, float g, float bl, float alpha) {
        final int seg = 32, rows = 6;
        final float lo = -0.15f, hi = (float) (Math.PI / 2.0);
        for (int i = 0; i < seg; i++) {
            float a0 = (float) i / seg * TAU, a1 = (float) (i + 1) / seg * TAU;
            for (int j = 0; j < rows; j++) {
                float e0 = lerp(lo, hi, (float) j / rows), e1 = lerp(lo, hi, (float) (j + 1) / rows);
                tintVertex(b, a0, e0, lo, hi, r, g, bl, alpha);
                tintVertex(b, a1, e0, lo, hi, r, g, bl, alpha);
                tintVertex(b, a1, e1, lo, hi, r, g, bl, alpha);
                tintVertex(b, a0, e1, lo, hi, r, g, bl, alpha);
            }
        }
    }

    private static void tintVertex(SkyBatch b, float az, float el, float lo, float hi,
                                   float r, float g, float bl, float alpha) {
        float ce = cos(el);
        float a = alpha * (0.75f + 0.25f * (1f - (el - lo) / (hi - lo)));
        b.v(ce * cos(az), sin(el), ce * sin(az), r, g, bl, Math.min(1f, a));
    }

    // =========================================================== tangent-plane objects (planet, black hole)

    /** {direction(3), right(3), up(3)} for a spot on the sky given azimuth and elevation (radians). */
    private static float[] basis(float az, float el) {
        float ce = cos(el);
        float dx = ce * cos(az), dy = sin(el), dz = ce * sin(az);
        float rx = -sin(az), rz = cos(az);
        return new float[]{dx, dy, dz, rx, 0f, rz, dy * rz, dz * rx - dx * rz, -dy * rx};
    }

    private static void pv(SkyBatch b, float[] f, float u, float v, float r, float g, float bl, float a) {
        b.v(f[0] + f[3] * u + f[6] * v, f[1] + f[4] * u + f[7] * v, f[2] + f[5] * u + f[8] * v, r, g, bl, a);
    }

    private static void ringPoint(SkyBatch b, float[] f, float rad, float ang, float squash, float tilt,
                                  float r, float g, float bl, float a) {
        float uu = rad * cos(ang), vv = rad * sin(ang) * squash;
        float ct = cos(tilt), st = sin(tilt);
        pv(b, f, uu * ct - vv * st, uu * st + vv * ct, r, g, bl, a);
    }

    /** Soft glowing ring: transparent at both edges, brightest in the middle. */
    private static void softRing(SkyBatch b, float[] f, float r0, float r1, float squash, float tilt,
                                 float cr, float cg, float cb, float alpha, int segs) {
        float rm = (r0 + r1) * 0.5f;
        for (int j = 0; j < segs; j++) {
            float a0 = (float) j / segs * TAU, a1 = (float) (j + 1) / segs * TAU;
            ringPoint(b, f, r0, a0, squash, tilt, cr, cg, cb, 0f);
            ringPoint(b, f, rm, a0, squash, tilt, cr, cg, cb, alpha);
            ringPoint(b, f, rm, a1, squash, tilt, cr, cg, cb, alpha);
            ringPoint(b, f, r0, a1, squash, tilt, cr, cg, cb, 0f);

            ringPoint(b, f, rm, a0, squash, tilt, cr, cg, cb, alpha);
            ringPoint(b, f, r1, a0, squash, tilt, cr, cg, cb, 0f);
            ringPoint(b, f, r1, a1, squash, tilt, cr, cg, cb, 0f);
            ringPoint(b, f, rm, a1, squash, tilt, cr, cg, cb, alpha);
        }
    }

    // ---- planet (alpha batch) ----

    private static final float PLANET_AZ = 2.1f, PLANET_EL = 0.16f, PLANET_RHO = 0.115f, PLANET_TILT = 0.22f;

    /** half = 0: back half of the rings (drawn before the planet), 1: front half (drawn after). */
    static void planetRing(SkyBatch b, int half, float vis) {
        float[] f = basis(PLANET_AZ, PLANET_EL);
        final int bands = 12, segs = 28;
        float start = half == 0 ? 0f : (float) Math.PI;
        for (int k = 0; k < bands; k++) {
            float n0 = (float) k / bands, n1 = (float) (k + 1) / bands;
            float rad0 = lerp(1.45f, 2.35f, n0) * PLANET_RHO, rad1 = lerp(1.45f, 2.35f, n1) * PLANET_RHO;
            float mid = (n0 + n1) * 0.5f;
            float edge = Math.min(smooth01(mid / 0.12f), smooth01((1f - mid) / 0.12f));
            float a = 0.70f * (0.30f + 0.70f * Math.abs(sin(mid * 23f))) * edge * vis;
            for (int j = 0; j < segs; j++) {
                float a0 = start + (float) j / segs * (float) Math.PI;
                float a1 = start + (float) (j + 1) / segs * (float) Math.PI;
                ringPoint(b, f, rad0, a0, 0.27f, PLANET_TILT, 0.88f, 0.82f, 0.98f, a);
                ringPoint(b, f, rad1, a0, 0.27f, PLANET_TILT, 0.88f, 0.82f, 0.98f, a);
                ringPoint(b, f, rad1, a1, 0.27f, PLANET_TILT, 0.88f, 0.82f, 0.98f, a);
                ringPoint(b, f, rad0, a1, 0.27f, PLANET_TILT, 0.88f, 0.82f, 0.98f, a);
            }
        }
    }

    private static float smooth01(float x) {
        float t = clamp(x, 0f, 1f);
        return t * t * (3f - 2f * t);
    }

    static void planetBody(SkyBatch b, float vis) {
        float[] f = basis(PLANET_AZ, PLANET_EL);
        final int rings = 6, segs = 36;
        for (int k = 0; k < rings; k++) {
            float r0 = (float) k / rings, r1 = (float) (k + 1) / rings;
            for (int j = 0; j < segs; j++) {
                float a0 = (float) j / segs * TAU, a1 = (float) (j + 1) / segs * TAU;
                planetVertex(b, f, r0, a0, vis);
                planetVertex(b, f, r1, a0, vis);
                planetVertex(b, f, r1, a1, vis);
                planetVertex(b, f, r0, a1, vis);
            }
        }
    }

    private static void planetVertex(SkyBatch b, float[] f, float rn, float ang, float vis) {
        float nu = rn * cos(ang), nv = rn * sin(ang);
        float band = 0.5f + 0.5f * sin(nv * 9f + 0.7f * sin(nu * 3f + 1f) + 0.4f);
        float r = lerp(0.60f, 0.82f, band), g = lerp(0.50f, 0.76f, band), bl = lerp(0.84f, 0.97f, band);
        float light = clamp(0.62f + 0.55f * (-0.55f * nu + 0.65f * nv), 0.18f, 1.05f);
        float edge = (float) Math.sqrt(Math.max(0f, 1f - (nu * nu + nv * nv)));
        light *= 0.78f + 0.22f * edge;
        pv(b, f, nu * PLANET_RHO, nv * PLANET_RHO, Math.min(1f, r * light), Math.min(1f, g * light), Math.min(1f, bl * light), 0.97f * vis);
    }

    // ---- black hole ----

    private static final float HOLE_AZ = 5.35f, HOLE_EL = 0.075f, HOLE_RHO = 0.034f;

    /** The dark disc itself (alpha batch). */
    static void blackHoleDisc(SkyBatch b, float vis) {
        float[] f = basis(HOLE_AZ, HOLE_EL);
        final int segs = 28;
        for (int j = 0; j < segs; j++) {
            float a0 = (float) j / segs * TAU, a1 = (float) (j + 1) / segs * TAU;
            pv(b, f, 0f, 0f, 0f, 0f, 0f, 0.97f * vis);
            pv(b, f, HOLE_RHO * cos(a0), HOLE_RHO * sin(a0), 0f, 0f, 0f, 0.97f * vis);
            pv(b, f, HOLE_RHO * cos(a1), HOLE_RHO * sin(a1), 0f, 0f, 0f, 0.97f * vis);
            pv(b, f, 0f, 0f, 0f, 0f, 0f, 0.97f * vis);
        }
    }

    /** Glow, glowing rings and the vertical jet (additive batch). */
    static void blackHoleLight(SkyBatch b, float t, float strength) {
        float[] f = basis(HOLE_AZ, HOLE_EL);
        float pulse = 0.88f + 0.12f * sin(t * 2f);
        float rho = HOLE_RHO;

        // soft purple halo
        final int gr = 5, gs = 32;
        for (int k = 0; k < gr; k++) {
            float r0 = (float) k / gr, r1 = (float) (k + 1) / gr;
            float a0 = 0.30f * (1f - r0) * (1f - r0) * strength, a1 = 0.30f * (1f - r1) * (1f - r1) * strength;
            for (int j = 0; j < gs; j++) {
                float t0 = (float) j / gs * TAU, t1 = (float) (j + 1) / gs * TAU;
                float rr0 = r0 * rho * 7f, rr1 = r1 * rho * 7f;
                pv(b, f, rr0 * cos(t0), rr0 * sin(t0), 0.70f, 0.25f, 1.0f, a0);
                pv(b, f, rr1 * cos(t0), rr1 * sin(t0), 0.70f, 0.25f, 1.0f, a1);
                pv(b, f, rr1 * cos(t1), rr1 * sin(t1), 0.70f, 0.25f, 1.0f, a1);
                pv(b, f, rr0 * cos(t1), rr0 * sin(t1), 0.70f, 0.25f, 1.0f, a0);
            }
        }

        softRing(b, f, rho * 1.00f, rho * 1.40f, 0.60f, 0f, 0.95f, 0.80f, 1.00f, 0.85f * pulse * strength, 40);
        softRing(b, f, rho * 1.50f, rho * 1.95f, 0.60f, 0f, 0.75f, 0.35f, 1.00f, 0.45f * pulse * strength, 40);
        softRing(b, f, rho * 2.30f, rho * 3.30f, 0.60f, 0f, 0.60f, 0.20f, 0.95f, 0.20f * strength, 40);

        // vertical jet
        final int js = 10;
        for (int i = 0; i < js; i++) {
            float v0 = lerp(rho * 0.5f, 0.55f, (float) i / js), v1 = lerp(rho * 0.5f, 0.55f, (float) (i + 1) / js);
            float n0 = (float) i / js, n1 = (float) (i + 1) / js;
            float a0 = 0.70f * (float) Math.pow(1f - n0, 1.4f) * strength, a1 = 0.70f * (float) Math.pow(1f - n1, 1.4f) * strength;
            float w0 = 0.0045f * (1f - n0 * 0.6f), w1 = 0.0045f * (1f - n1 * 0.6f);
            float r0 = lerp(1f, 0.7f, n0), g0 = lerp(1f, 0.4f, n0), b0 = 1f;
            float r1 = lerp(1f, 0.7f, n1), g1 = lerp(1f, 0.4f, n1);
            pv(b, f, -w0, v0, r0, g0, b0, a0);
            pv(b, f, w0, v0, r0, g0, b0, a0);
            pv(b, f, w1, v1, r1, g1, b0, a1);
            pv(b, f, -w1, v1, r1, g1, b0, a1);
            // wide faint copy
            pv(b, f, -w0 * 3f, v0, r0, g0, b0, a0 * 0.18f);
            pv(b, f, w0 * 3f, v0, r0, g0, b0, a0 * 0.18f);
            pv(b, f, w1 * 3f, v1, r1, g1, b0, a1 * 0.18f);
            pv(b, f, -w1 * 3f, v1, r1, g1, b0, a1 * 0.18f);
        }
    }
}
