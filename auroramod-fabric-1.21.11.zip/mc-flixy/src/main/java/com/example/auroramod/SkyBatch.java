package com.example.auroramod;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import org.joml.Matrix4fc;

/** One draw call's worth of sky geometry. Vertices are unit-sphere directions; the dome radius is applied here. */
final class SkyBatch {
    static final ByteBufferBuilder ALLOCATOR = new ByteBufferBuilder(1 << 18);

    final RenderPipeline pipeline;
    final BufferBuilder buf;
    final Matrix4fc pose;
    final boolean premultiply;
    final float radius;
    int vertices;

    SkyBatch(RenderPipeline pipeline, Matrix4fc pose, boolean premultiply, float radius) {
        this.pipeline = pipeline;
        this.pose = pose;
        this.premultiply = premultiply;
        this.radius = radius;
        this.buf = new BufferBuilder(ALLOCATOR, pipeline.getVertexFormatMode(), pipeline.getVertexFormat());
    }

    void v(float x, float y, float z, float r, float g, float b, float a) {
        if (premultiply) {
            buf.addVertex(pose, x * radius, y * radius, z * radius).setColor(r * a, g * a, b * a, a);
        } else {
            buf.addVertex(pose, x * radius, y * radius, z * radius).setColor(r, g, b, a);
        }
        vertices++;
    }
}
