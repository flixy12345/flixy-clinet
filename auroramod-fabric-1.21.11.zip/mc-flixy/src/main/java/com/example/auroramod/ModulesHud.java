package com.example.auroramod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/** Clean HUD modules: FPS pill and keystrokes, in the same bubble style as the tracker. */
public final class ModulesHud {
    private static long lastNs = System.nanoTime();
    private static int frames = 0;
    private static int fps = 0;

    private ModulesHud() {}

    public static void render(GuiGraphics g) {
        AuroraConfig c = AuroraConfig.get();
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui) return;

        frames++;
        long now = System.nanoTime();
        if (now - lastNs >= 500_000_000L) {
            fps = (int) (frames * 1_000_000_000L / (now - lastNs));
            frames = 0;
            lastNs = now;
        }

        Font font = mc.font;
        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        float s = c.modScale;

        if (c.fpsHud) {
            String val = String.valueOf(fps);
            int color = fps >= 60 ? HudStyle.GREEN : (fps >= 30 ? HudStyle.GOLD : HudStyle.RED);
            int w = HudStyle.width(font, "FPS", 0.75f, true) + 6 + HudStyle.width(font, val, 1.0f, true) + 12;
            int h = 17;
            g.pose().pushMatrix();
            g.pose().translate(sw - w * s - 6f, 6f);
            g.pose().scale(s, s);
            HudStyle.panel(g, 0, 0, w, h, 0xC8);
            HudStyle.text(g, font, "FPS", 6, 5, HudStyle.GREY, 0.75f, true);
            HudStyle.text(g, font, val, 6 + HudStyle.width(font, "FPS", 0.75f, true) + 6, 4, color, 1.0f, true);
            g.pose().popMatrix();
        }

        if (c.keysHud) {
            int totalW = 58, totalH = 68;
            g.pose().pushMatrix();
            g.pose().translate(6f, sh - totalH * s - 40f);
            g.pose().scale(s, s);
            key(g, font, 20, 0, 18, 18, "W", mc.options.keyUp.isDown());
            key(g, font, 0, 20, 18, 18, "A", mc.options.keyLeft.isDown());
            key(g, font, 20, 20, 18, 18, "S", mc.options.keyDown.isDown());
            key(g, font, 40, 20, 18, 18, "D", mc.options.keyRight.isDown());
            key(g, font, 0, 40, 58, 12, "SPACE", mc.options.keyJump.isDown());
            key(g, font, 0, 54, 28, 14, "LMB", mc.options.keyAttack.isDown());
            key(g, font, 30, 54, 28, 14, "RMB", mc.options.keyUse.isDown());
            g.pose().popMatrix();
        }
    }

    private static void key(GuiGraphics g, Font font, int x, int y, int w, int h, String label, boolean down) {
        int bg = down ? 0xEEFFFFFF : 0xC8101216;
        HudStyle.roundRect(g, x, y, w, h, 3, bg);
        int color = down ? 0xFF101216 : HudStyle.WHITE;
        float scale = h >= 16 ? 1.0f : 0.8f;
        int tw = HudStyle.width(font, label, scale, true);
        HudStyle.text(g, font, label, x + (w - tw) / 2f, y + (h - 9 * scale) / 2f + 0.5f, color, scale, true);
    }
}
