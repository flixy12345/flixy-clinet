package com.example.auroramod.gui;

import com.example.auroramod.AuroraConfig;
import com.example.auroramod.ChartRenderer;
import com.example.auroramod.HudAnimator;
import com.example.auroramod.HudStyle;
import com.example.auroramod.MoneyHud;
import com.example.auroramod.MoneyTracker;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/** Launcher-style settings: a black window with a clickable menu down the side. Everything applies live. */
public class AuroraSettingsScreen extends Screen {
    // page names, indexed by page number
    private static final String[] NAMES = {"Tracker", "Money", "Sky", "Aurora", "Motion", "Colors", "HUD", "Appearance", "Modules"};
    private static final int T_TRACKER = 0, T_MONEY = 1, T_SKY = 2, T_AURORA = 3, T_MOTION = 4,
            T_COLORS = 5, T_HUD = 6, T_DISPLAY = 7, T_MODULES = 8;
    // the side menu: sections of pages
    private static final String[] SECTION_NAMES = {"MODULES", "VISUALS", "GENERAL"};
    private static final int[][] SECTIONS = {
            {T_TRACKER, T_MONEY, T_HUD, T_MODULES},
            {T_SKY, T_AURORA, T_MOTION, T_COLORS},
            {T_DISPLAY}};
    private static final int DARK = 0xFF0B0B0D;
    private static final int WHITE = 0xFFFFFFFF, GOLD = 0xFFFFD166;
    private static int lastTab = 0;

    private final Screen parent;
    private int colW, contentW, gap = 10, sideW = 104, x0, x1, y0, step = 24, slot, slotBase;
    private int winX, winY, winW, winH;
    private final List<Object[]> labels = new ArrayList<>(); // {String text, Integer x, Integer y}
    private final List<int[]> items = new ArrayList<>();      // side menu: {page, y}
    private final List<int[]> headers = new ArrayList<>();    // side menu: {section, y}

    public AuroraSettingsScreen(Screen parent) {
        super(Component.literal("Aurora Client"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        AuroraConfig c = AuroraConfig.get();
        slot = 0;
        labels.clear();
        items.clear();
        headers.clear();

        colW = Math.min(150, (width - 12 - sideW - 18 - gap) / 2);
        contentW = colW * 2 + gap;
        winW = sideW + 8 + contentW + 10;
        winH = Math.min(238, height - 4);
        winX = (width - winW) / 2;
        winY = Math.max(4, (height - winH) / 2);
        x0 = winX + sideW + 8;
        x1 = x0 + colW + gap;
        y0 = winY + 14;
        slotBase = y0;

        // clickable menu down the side (the look is drawn in drawSidebar; these buttons just take the clicks)
        int cy = winY + 8;
        for (int sec = 0; sec < SECTIONS.length; sec++) {
            headers.add(new int[]{sec, cy});
            cy += 11;
            for (int page : SECTIONS[sec]) {
                items.add(new int[]{page, cy});
                final int target = page;
                addRenderableWidget(Button.builder(Component.empty(), b -> {
                    lastTab = target;
                    clearWidgets();
                    init();
                }).bounds(winX + 6, cy, sideW - 8, 16).build());
                cy += 17;
            }
            cy += 3;
        }

        switch (lastTab) {
            case T_TRACKER:
                slotBase = y0 + 92; // the chart is drawn above the buttons
                cycle("Range", AuroraConfig.RANGE_NAMES, () -> c.chartRange, v -> c.chartRange = v);
                toggle("Chart in HUD", () -> c.showChart, v -> c.showChart = v);
                button("New session", MoneyTracker::resetSession);
                button("Reset all-time", MoneyTracker::resetLifetime);
                break;
            case T_MONEY:
                toggle("Track money", () -> c.moneyTracking, v -> c.moneyTracking = v);
                toggle("Only on matching server", () -> c.moneyServerOnly, v -> c.moneyServerOnly = v);
                field("Server contains:", c.moneyServer, s -> c.moneyServer = s);
                field("Scoreboard line:", c.moneyKeyword, s -> c.moneyKeyword = s);
                break;
            case T_SKY:
                toggle("Sky effects", () -> c.auroraEnabled, v -> c.auroraEnabled = v);
                cycle("Style", AuroraConfig.SKY_NAMES, () -> c.skyStyle, v -> c.skyStyle = v);
                slider("Sky tint", 0, 1, 2, "", () -> c.skyTint, v -> c.skyTint = (float) v);
                slider("Star density", 0, 2, 2, "x", () -> c.starDensity, v -> c.starDensity = (float) v);
                slider("Lightning", 0.3, 1.5, 2, "x", () -> c.lightning, v -> c.lightning = (float) v);
                slider("Nebula", 0, 1.5, 2, "", () -> c.nebula, v -> c.nebula = (float) v);
                toggle("Black hole", () -> c.blackHole, v -> c.blackHole = v);
                toggle("Ringed planet", () -> c.planet, v -> c.planet = v);
                break;
            case T_AURORA:
                slider("Intensity", 0, 2, 2, "", () -> c.intensity, v -> c.intensity = (float) v);
                slider("Coverage", 0, 1, 2, "", () -> c.coverage, v -> c.coverage = (float) v);
                slider("Horizon glow", 0, 1, 2, "", () -> c.horizonGlow, v -> c.horizonGlow = (float) v);
                slider("Top fade", 0.5, 3, 2, "", () -> c.falloff, v -> c.falloff = (float) v);
                slider("Base height", 0, 30, 0, "\u00b0", () -> c.baseElevation, v -> c.baseElevation = (float) v);
                slider("Top height", 20, 85, 0, "\u00b0", () -> c.topElevation, v -> c.topElevation = (float) v);
                slider("Rotation", 0, 360, 0, "\u00b0", () -> c.rotation, v -> c.rotation = (float) v);
                slider("Daytime visibility", 0, 1, 2, "", () -> c.dayVisibility, v -> c.dayVisibility = (float) v);
                slider("Rain dimming", 0, 1, 2, "", () -> c.rainDimming, v -> c.rainDimming = (float) v);
                cycle("Quality", AuroraConfig.QUALITY_NAMES, () -> c.quality, v -> c.quality = v);
                break;
            case T_MOTION:
                slider("Speed", 0, 3, 2, "x", () -> c.speed, v -> c.speed = (float) v);
                slider("Waves", 0, 2, 2, "", () -> c.waves, v -> c.waves = (float) v);
                slider("Shimmer", 0, 1.5, 2, "", () -> c.shimmer, v -> c.shimmer = (float) v);
                slider("Ray density", 0.3, 2, 2, "x", () -> c.rayDensity, v -> c.rayDensity = (float) v);
                slider("Flicker", 0, 1.5, 2, "", () -> c.flicker, v -> c.flicker = (float) v);
                slider("Color cycling", 0, 2, 2, "", () -> c.colorCycle, v -> c.colorCycle = (float) v);
                break;
            case T_COLORS:
                // Aurora style only. Set Preset to "Custom" to use the RGB sliders.
                cycle("Preset", AuroraConfig.PRESET_NAMES, () -> c.preset, v -> c.preset = v);
                slider("Hue shift", 0, 360, 0, "\u00b0", () -> c.hueShift, v -> c.hueShift = (float) v);
                slider("Saturation", 0, 1.5, 2, "", () -> c.saturation, v -> c.saturation = (float) v);
                rgb("Bottom", c.customBottom);
                rgb("Middle", c.customMiddle);
                rgb("Top", c.customTop);
                break;
            case T_HUD:
                toggle("Slide HUD", () -> c.slideEnabled, v -> { c.slideEnabled = v; if (!v) HudAnimator.setCentered(false); });
                toggle("Hold key (not toggle)", () -> c.holdMode, v -> c.holdMode = v);
                slider("Duration", 0.1, 2, 2, "s", () -> c.duration, v -> c.duration = (float) v);
                cycle("Easing", AuroraConfig.EASING_NAMES, () -> c.easing, v -> c.easing = v);
                slider("Gap under crosshair", 0, 120, 0, "px", () -> c.gap, v -> c.gap = (float) v);
                slider("Horizontal offset", -200, 200, 0, "px", () -> c.hudOffsetX, v -> c.hudOffsetX = (float) v);
                slider("Scale when centered", 0.5, 2, 2, "x", () -> c.hudScale, v -> c.hudScale = (float) v);
                toggle("Move hotbar", () -> c.moveHotbar, v -> c.moveHotbar = v);
                toggle("Move health/hunger", () -> c.moveStatus, v -> c.moveStatus = v);
                toggle("Move XP bar", () -> c.moveXp, v -> c.moveXp = v);
                toggle("Move item name", () -> c.moveItemName, v -> c.moveItemName = v);
                button("Preview slide", HudAnimator::toggle);
                break;
            case T_DISPLAY:
                toggle("Money HUD", () -> c.moneyHud, v -> c.moneyHud = v);
                toggle("Compact numbers", () -> c.moneyCompact, v -> c.moneyCompact = v);
                cycle("Corner", AuroraConfig.ANCHOR_NAMES, () -> c.moneyAnchor, v -> c.moneyAnchor = v);
                slider("X offset", 0, 300, 0, "px", () -> c.moneyX, v -> c.moneyX = (float) v);
                slider("Y offset", 0, 300, 0, "px", () -> c.moneyY, v -> c.moneyY = (float) v);
                slider("Scale", 0.5, 2, 2, "x", () -> c.moneyScale, v -> c.moneyScale = (float) v);
                slider("Background", 0, 1, 2, "", () -> c.moneyBg, v -> c.moneyBg = (float) v);
                toggle("Earned / lost", () -> c.showEarnedLost, v -> c.showEarnedLost = v);
                toggle("Per hour", () -> c.showRate, v -> c.showRate = v);
                toggle("Session time", () -> c.showTime, v -> c.showTime = v);
                toggle("All-time total", () -> c.showLifetime, v -> c.showLifetime = v);
                slider("Recent changes", 0, 10, 0, "", () -> c.recentCount, v -> c.recentCount = (int) Math.round(v));
                break;
            default:
                toggle("FPS counter", () -> c.fpsHud, v -> c.fpsHud = v);
                toggle("Keystrokes", () -> c.keysHud, v -> c.keysHud = v);
                slider("Module scale", 0.5, 2, 2, "x", () -> c.modScale, v -> c.modScale = (float) v);
                break;
        }

        int footerY = winY + winH - 26;
        addRenderableWidget(Button.builder(Component.literal("Reset all"), b -> {
            AuroraConfig.reset();
            clearWidgets();
            init();
        }).bounds(x0, footerY, colW, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(x1, footerY, colW, 20).build());
    }

    // ---- widget helpers (each takes the next grid slot) ----

    private int sx() { return slot % 2 == 0 ? x0 : x1; }
    private int sy() { return slotBase + (slot / 2) * step; }

    private void slider(String label, double min, double max, int decimals, String unit,
                        DoubleSupplier get, DoubleConsumer set) {
        addRenderableWidget(new ConfigSlider(sx(), sy(), colW, label, min, max, decimals, unit, get, set));
        slot++;
    }

    private void toggle(String label, BooleanSupplier get, Consumer<Boolean> set) {
        Button w = Button.builder(toggleText(label, get.getAsBoolean()), btn -> {
            boolean v = !get.getAsBoolean();
            set.accept(v);
            btn.setMessage(toggleText(label, v));
        }).bounds(sx(), sy(), colW, 20).build();
        addRenderableWidget(w);
        slot++;
    }

    private static Component toggleText(String label, boolean on) {
        return Component.literal(label + ": ").append(Component.literal(on ? "ON" : "OFF")
                .withStyle(on ? ChatFormatting.GREEN : ChatFormatting.RED));
    }

    private void cycle(String label, String[] names, IntSupplier get, IntConsumer set) {
        Button w = Button.builder(Component.literal(label + ": " + names[get.getAsInt()]), btn -> {
            int v = (get.getAsInt() + 1) % names.length;
            set.accept(v);
            btn.setMessage(Component.literal(label + ": " + names[v]));
        }).bounds(sx(), sy(), colW, 20).build();
        addRenderableWidget(w);
        slot++;
    }

    private void button(String label, Runnable action) {
        addRenderableWidget(Button.builder(Component.literal(label), b -> action.run())
                .bounds(sx(), sy(), colW, 20).build());
        slot++;
    }

    /** A label on the left and a text box on the right, on one row. */
    private void field(String label, String value, Consumer<String> set) {
        if (slot % 2 == 1) slot++;
        labels.add(new Object[]{label, x0 + 2, sy() + 6});
        slot++;
        EditBox f = new EditBox(font, sx(), sy(), colW, 20, Component.literal(label));
        f.setMaxLength(40);
        f.setValue(value);
        f.setResponder(set);
        addRenderableWidget(f);
        slot++;
    }

    private void rgb(String name, float[] col) {
        String[] ch = {"R", "G", "B"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            slider(name + " " + ch[i], 0, 255, 0, "",
                    () -> col[idx] * 255.0, v -> col[idx] = (float) (v / 255.0));
        }
    }

    // ---- drawing ----

    @Override
    public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        // No blur: the sky and HUD stay visible around the window so changes preview live.
        HudStyle.panel(graphics, winX, winY, winW, winH, 0xE8);
        graphics.fill(winX + sideW + 3, winY + 10, winX + sideW + 4, winY + winH - 10, HudStyle.DIVIDER);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);

        drawSidebar(graphics, mouseX, mouseY);

        for (Object[] l : labels) {
            graphics.drawString(font, (String) l[0], (Integer) l[1], (Integer) l[2], WHITE);
        }

        if (lastTab == T_TRACKER) {
            drawTracker(graphics);
        } else if (lastTab == T_MONEY) {
            HudStyle.text(graphics, font, "Status: " + MoneyTracker.status(), x0, y0 + 4 * step + 4, GOLD, 0.85f, false);
        }
    }

    /** Section headings, icons, the outlined selected item and the profile card. */
    private void drawSidebar(GuiGraphics g, int mouseX, int mouseY) {
        int x = winX + 6, w = sideW - 8, h = 16;
        for (int[] hd : headers) {
            HudStyle.text(g, font, SECTION_NAMES[hd[0]], x + 4, hd[1] + 1, HudStyle.GREY, 0.62f, true);
        }
        for (int[] it : items) {
            int page = it[0], y = it[1];
            boolean sel = page == lastTab;
            boolean hover = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
            g.fill(x, y, x + w, y + h, 0xF2000000); // covers the button's own look
            if (sel) {
                HudStyle.roundRect(g, x, y, w, h, 5, 0xFFE8E8EA);
                HudStyle.roundRect(g, x + 1, y + 1, w - 2, h - 2, 4, DARK);
                g.fill(winX + 3, y + 3, winX + 5, y + h - 3, HudStyle.WHITE);
            } else if (hover) {
                HudStyle.roundRect(g, x, y, w, h, 5, 0x18FFFFFF);
            }
            icon(g, page, x + 6, y + 3, sel ? HudStyle.WHITE : 0xFFA8ACB5);
            HudStyle.text(g, font, NAMES[page], x + 22, y + 4, sel ? HudStyle.WHITE : 0xFFC4C8CF, 0.95f, sel);
        }
        drawProfile(g);
    }

    /** Tiny 10x10 icons made of plain fills. */
    private void icon(GuiGraphics g, int page, int x, int y, int c) {
        switch (page) {
            case T_TRACKER: // bar chart
                g.fill(x, y + 5, x + 2, y + 10, c);
                g.fill(x + 4, y + 2, x + 6, y + 10, c);
                g.fill(x + 8, y, x + 10, y + 10, c);
                break;
            case T_MONEY: // coin
                HudStyle.roundRect(g, x, y, 10, 10, 5, c);
                HudStyle.roundRect(g, x + 2, y + 2, 6, 6, 3, DARK);
                g.fill(x + 4, y + 4, x + 6, y + 6, c);
                break;
            case T_HUD: // box with two lines
                g.fill(x, y, x + 10, y + 1, c);
                g.fill(x, y + 9, x + 10, y + 10, c);
                g.fill(x, y, x + 1, y + 10, c);
                g.fill(x + 9, y, x + 10, y + 10, c);
                g.fill(x + 2, y + 3, x + 8, y + 4, c);
                g.fill(x + 2, y + 6, x + 6, y + 7, c);
                break;
            case T_MODULES: // 2x2 grid
            case T_DISPLAY:
                g.fill(x, y, x + 4, y + 4, c);
                g.fill(x + 6, y, x + 10, y + 4, page == T_DISPLAY ? 0xFF6B6F78 : c);
                g.fill(x, y + 6, x + 4, y + 10, page == T_DISPLAY ? 0xFF6B6F78 : c);
                g.fill(x + 6, y + 6, x + 10, y + 10, c);
                break;
            case T_SKY: // moon
                HudStyle.roundRect(g, x, y, 10, 10, 5, c);
                HudStyle.roundRect(g, x + 3, y - 1, 9, 9, 4, DARK);
                break;
            case T_AURORA: // curtains
                g.fill(x + 1, y + 3, x + 3, y + 10, c);
                g.fill(x + 4, y, x + 6, y + 10, c);
                g.fill(x + 7, y + 2, x + 9, y + 10, c);
                break;
            case T_MOTION: // rising steps
                g.fill(x, y + 7, x + 3, y + 10, c);
                g.fill(x + 3, y + 4, x + 6, y + 7, c);
                g.fill(x + 6, y + 1, x + 9, y + 4, c);
                break;
            default: // colors: three dots
                HudStyle.roundRect(g, x, y + 3, 4, 4, 2, c);
                HudStyle.roundRect(g, x + 6, y, 4, 4, 2, c);
                HudStyle.roundRect(g, x + 6, y + 6, 4, 4, 2, c);
                break;
        }
    }

    /** Profile card at the bottom of the side menu: avatar, status and your name. */
    private void drawProfile(GuiGraphics g) {
        int x = winX + 6, w = sideW - 8, y = winY + winH - 32, h = 26;
        HudStyle.roundRect(g, x, y, w, h, 6, 0x26FFFFFF);
        int ax = x + 4, ay = y + 4;
        HudStyle.roundRect(g, ax, ay, 18, 18, 4, 0xFFF5C518);
        g.fill(ax + 4, ay + 6, ax + 7, ay + 9, 0xFF111111);
        g.fill(ax + 11, ay + 6, ax + 14, ay + 9, 0xFF111111);
        g.fill(ax + 6, ay + 11, ax + 12, ay + 14, 0xFFE0701A);

        boolean tracking = MoneyTracker.isActive();
        g.fill(x + 27, y + 7, x + 30, y + 10, tracking ? HudStyle.GREEN : HudStyle.GREY);
        HudStyle.text(g, font, tracking ? "Tracking" : "Idle", x + 33, y + 6, HudStyle.GREY, 0.62f, false);

        String name = minecraft != null && minecraft.player != null ? minecraft.player.getName().getString() : "Player";
        while (name.length() > 1 && HudStyle.width(font, name, 0.9f, true) > w - 32) {
            name = name.substring(0, name.length() - 1);
        }
        HudStyle.text(g, font, name, x + 27, y + 14, HudStyle.WHITE, 0.9f, true);
    }

    /** Big session number + the day-trading style chart. */
    private void drawTracker(GuiGraphics graphics) {
        AuroraConfig c = AuroraConfig.get();
        boolean active = MoneyTracker.isActive();
        boolean cp = c.moneyCompact;

        List<double[]> pts;
        double baseline, bal, start;
        if (active) {
            pts = MoneyTracker.chartPoints(c.chartRange);
            baseline = MoneyTracker.chartBaseline(c.chartRange, pts);
            bal = MoneyTracker.balance();
            start = MoneyTracker.startBalance();
        } else {
            pts = MoneyHud.demoPoints();
            baseline = pts.get(0)[1];
            start = baseline;
            bal = pts.get(pts.size() - 1)[1];
        }
        double net = bal - start;

        HudStyle.text(graphics, font, MoneyTracker.signed(net, cp), x0, y0 + 1,
                net >= 0 ? HudStyle.GREEN : HudStyle.RED, 2.0f, true);

        String r1 = "Balance $" + MoneyTracker.format(bal, cp);
        String r2 = "Started with $" + MoneyTracker.format(start, cp);
        int right = x0 + contentW;
        HudStyle.text(graphics, font, r1, right - HudStyle.width(font, r1, 0.85f, true), y0 + 2, HudStyle.GOLD, 0.85f, true);
        HudStyle.text(graphics, font, r2, right - HudStyle.width(font, r2, 0.75f, false), y0 + 14, HudStyle.GREY, 0.75f, false);

        HudStyle.roundRect(graphics, x0 - 2, y0 + 24, contentW + 4, 66, 5, 0x66000000);
        ChartRenderer.draw(graphics, font, x0 + 2, y0 + 27, contentW - 4, 60, pts, baseline, true, cp);

        String note = active ? "Status: " + MoneyTracker.status()
                : "Sample chart. Join donutsmp.net to track your own money.";
        HudStyle.text(graphics, font, note, x0, y0 + 92 + 52, active ? GOLD : HudStyle.GREY, 0.8f, false);
    }

    @Override
    public boolean isPauseScreen() {
        return false; // keep the world (and the sky) running while you tweak
    }

    @Override
    public void onClose() {
        AuroraConfig.save();
        minecraft.setScreen(parent);
    }

    private static final class ConfigSlider extends AbstractSliderButton {
        private final String label, unit;
        private final double min, max;
        private final int decimals;
        private final DoubleConsumer set;

        ConfigSlider(int x, int y, int w, String label, double min, double max, int decimals, String unit,
                     DoubleSupplier get, DoubleConsumer set) {
            super(x, y, w, 20, Component.empty(), Math.max(0, Math.min(1, (get.getAsDouble() - min) / (max - min))));
            this.label = label;
            this.unit = unit;
            this.min = min;
            this.max = max;
            this.decimals = decimals;
            this.set = set;
            updateMessage();
        }

        private double current() { return min + (max - min) * value; }

        @Override
        protected void updateMessage() {
            setMessage(Component.literal(label + ": " + String.format("%." + decimals + "f", current()) + unit));
        }

        @Override
        protected void applyValue() {
            set.accept(current());
        }
    }
}
