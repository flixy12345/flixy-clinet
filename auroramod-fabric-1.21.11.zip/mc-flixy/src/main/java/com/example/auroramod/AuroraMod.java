package com.example.auroramod;

import com.example.auroramod.gui.AuroraSettingsScreen;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

public class AuroraMod implements ClientModInitializer {
    public static final String MOD_ID = "auroramod";

    public static KeyMapping hudCenterKey;
    public static KeyMapping settingsKey;
    public static KeyMapping resetMoneyKey;

    @Override
    public void onInitializeClient() {
        AuroraConfig.load();
        MoneyTracker.loadHistory();

        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath(MOD_ID, "main"));
        hudCenterKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.auroramod.hud_center", InputConstants.Type.KEYSYM, InputConstants.KEY_V, category));
        settingsKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.auroramod.open_settings", InputConstants.Type.KEYSYM, InputConstants.KEY_K, category));
        resetMoneyKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.auroramod.reset_money", InputConstants.Type.KEYSYM, -1, category)); // unbound by default

        // Sky: drawn into the world just before translucent terrain.
        WorldRenderEvents.BEFORE_TRANSLUCENT.register(AuroraRenderer::render);

        // HUD slide: wraps the vanilla HUD elements (no mixins needed).
        HudAnimator.register();

        // Money bubble, layered just before the chat.
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(MOD_ID, "money"),
                (graphics, deltaTracker) -> MoneyHud.render(graphics));

        // FPS counter + keystrokes.
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(MOD_ID, "modules"),
                (graphics, deltaTracker) -> ModulesHud.render(graphics));

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> MoneyTracker.onJoin());
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            MoneyTracker.onConnectionChange();
            AuroraConfig.save();
            MoneyTracker.saveHistory();
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            AuroraConfig.save();
            MoneyTracker.saveHistory();
            AuroraRenderer.close();
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            AuroraConfig c = AuroraConfig.get();

            MoneyTracker.tick(client);
            while (resetMoneyKey.consumeClick()) {
                MoneyTracker.resetSession();
            }

            if (c.holdMode) {
                if (client.screen == null) {
                    HudAnimator.setCentered(c.slideEnabled && hudCenterKey.isDown());
                }
                while (hudCenterKey.consumeClick()) { /* swallow */ }
            } else {
                while (hudCenterKey.consumeClick()) {
                    HudAnimator.toggle();
                }
            }

            while (settingsKey.consumeClick()) {
                if (client.screen == null) {
                    client.setScreen(new AuroraSettingsScreen(null));
                }
            }
        });
    }
}
