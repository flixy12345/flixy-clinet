package com.example.auroramod;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.List;

/** Day-trading style line chart: green above the starting balance, red below, dashed baseline. */
public final class ChartRenderer {
    private ChartRenderer() {}

    /** pts = list of {timeMillis, balance}, oldest first. */
    public static void draw(GuiGraphics g, Font font, int x, int y, int w, int h,
                            List<double[]> pts, double baseline, boolean labels, boolean compact) {
        if (pts == null || pts.size() < 2 || w < 8 || h < 8) return;

        double t0 = pts.get(0)[0];
        double t1 = pts.get(pts.size() - 1)[0];
        if (t1 <= t0) t1 = t0 + 1;

        double dataMin = baseline, dataMax = baseline;
        for (double[] p : pts) {
            dataMin = Math.min(dataMin, p[1]);
            dataMax = Math.max(dataMax, p[1]);
        }
        double pad = Math.max((dataMax - dataMin) * 0.08, 1.0);
        double vMin = dataMin - pad, vMax = dataMax + pad;
        double range = vMax - vMin;

        int baseY = clamp((int) Math.round((h - 1) * (1.0 - (baseline - vMin) / range)), 0, h - 1);

        int idx = 0;
        int prevY = -1;
        int lastY = 0;
        for (int cx = 0; cx < w; cx++) {
            double t = t0 + (t1 - t0) * cx / (double) (w - 1);
            while (idx < pts.size() - 2 && pts.get(idx + 1)[0] < t) idx++;
            double[] a = pts.get(idx), b = pts.get(idx + 1);
            double span = b[0] - a[0];
            double f = span <= 0 ? 1.0 : Math.max(0.0, Math.min(1.0, (t - a[0]) / span));
            double v = a[1] + (b[1] - a[1]) * f;

            int py = clamp((int) Math.round((h - 1) * (1.0 - (v - vMin) / range)), 0, h - 1);
            int color = v >= baseline ? HudStyle.GREEN : HudStyle.RED;

            // soft area under the line
            g.fill(x + cx, y + py, x + cx + 1, y + h, (0x26 << 24) | (color & 0xFFFFFF));
            // the line itself (vertical run keeps it connected)
            int ya = prevY < 0 ? py : prevY;
            g.fill(x + cx, y + Math.min(ya, py), x + cx + 1, y + Math.max(ya, py) + 1, color);
            prevY = py;
            lastY = py;
        }

        // dashed starting-balance line
        for (int cx = 0; cx < w; cx += 4) {
            g.fill(x + cx, y + baseY, x + Math.min(cx + 2, w), y + baseY + 1, 0x66FFFFFF);
        }

        // dot at the latest value
        g.fill(x + w - 3, y + Math.max(0, lastY - 1), x + w, y + Math.min(h, lastY + 2), HudStyle.WHITE);

        if (labels) {
            HudStyle.text(g, font, "$" + MoneyTracker.format(dataMax, compact), x + 2, y + 1, HudStyle.GREY, 0.65f, false);
            HudStyle.text(g, font, "$" + MoneyTracker.format(dataMin, compact), x + 2, y + h - 7, HudStyle.GREY, 0.65f, false);
        }
    }

    private static int clamp(int v, int lo, int hi) {
        return v < lo ? lo : Math.min(v, hi);
    }
}
