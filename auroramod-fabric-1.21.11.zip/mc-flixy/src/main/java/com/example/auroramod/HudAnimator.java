package com.example.auroramod;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;

/**
 * Smoothly slides the main HUD from the bottom of the screen to just under the
 * crosshair by wrapping the vanilla HUD elements. The camera is never touched.
 */
public final class HudAnimator {
    public enum Element { HOTBAR, STATUS, XP, ITEM_NAME }

    private static boolean centered = false;
    private static float t = 0f;
    private static long last = System.currentTimeMillis();

    private HudAnimator() {}

    public static void toggle() { setCentered(!centered); }

    public static void setCentered(boolean value) {
        centered = value && AuroraConfig.get().slideEnabled;
    }

    public static boolean isCentered() { return centered; }

    // ---------- registration ----------

    public static void register() {
        wrap(VanillaHudElements.HOTBAR, Element.HOTBAR);
        wrap(VanillaHudElements.HEALTH_BAR, Element.STATUS);
        wrap(VanillaHudElements.ARMOR_BAR, Element.STATUS);
        wrap(VanillaHudElements.FOOD_BAR, Element.STATUS);
        wrap(VanillaHudElements.EXPERIENCE_LEVEL, Element.XP);
        wrap(VanillaHudElements.HELD_ITEM_TOOLTIP, Element.ITEM_NAME);

        // These ids are looked up by name; if one doesn't exist it is simply skipped.
        wrapIfPresent("info_bar", Element.XP);        // experience bar / locator bar
        wrapIfPresent("air_bar", Element.STATUS);
        wrapIfPresent("mount_health", Element.STATUS);
    }

    private static void wrap(Identifier id, Element element) {
        HudElementRegistry.replaceElement(id, original -> wrapElement(original, element));
    }

    private static void wrapIfPresent(String path, Element element) {
        try {
            wrap(Identifier.fromNamespaceAndPath("minecraft", path), element);
        } catch (Throwable ignored) {
            // element not present in this version
        }
    }

    private static HudElement wrapElement(HudElement original, Element element) {
        return (graphics, deltaTracker) -> {
            boolean pushed = begin(graphics, element);
            try {
                original.render(graphics, deltaTracker);
            } finally {
                if (pushed) graphics.pose().popMatrix();
            }
        };
    }

    // ---------- animation ----------

    private static void advance() {
        long now = System.currentTimeMillis();
        if (now == last) return;
        float dt = Math.min((now - last) / 1000f, 0.1f);
        last = now;
        AuroraConfig c = AuroraConfig.get();
        if (!c.slideEnabled) centered = false;
        float step = dt / Math.max(0.05f, c.duration);
        t = centered ? Math.min(1f, t + step) : Math.max(0f, t - step);
    }

    private static float ease(float x) {
        switch (AuroraConfig.get().easing) {
            case 1:  return x * x * (3f - 2f * x);                                // smoothstep
            case 2:  { float u = 1f - x; return 1f - u * u * u; }                  // ease out cubic
            case 3:  return 0.5f - 0.5f * (float) Math.cos(x * Math.PI);           // sine in-out
            case 4:  { float c1 = 1.70158f, c3 = c1 + 1f, u = x - 1f;              // ease out back
                       return 1f + c3 * u * u * u + c1 * u * u; }
            case 5:  return x;                                                    // linear
            default: return x * x * x * (x * (x * 6f - 15f) + 10f);                // smootherstep
        }
    }

    private static boolean applies(Element e) {
        AuroraConfig c = AuroraConfig.get();
        switch (e) {
            case HOTBAR: return c.moveHotbar;
            case STATUS: return c.moveStatus;
            case XP:     return c.moveXp;
            default:     return c.moveItemName;
        }
    }

    /** Pushes the slide transform. Returns true if a matrix was pushed (caller must pop it). */
    private static boolean begin(GuiGraphics graphics, Element element) {
        advance();
        AuroraConfig c = AuroraConfig.get();
        if (t <= 0f || !c.slideEnabled || !applies(element)) return false;

        var window = Minecraft.getInstance().getWindow();
        float cx = window.getGuiScaledWidth() / 2f;
        float cy = window.getGuiScaledHeight();
        float e = ease(t);
        float offY = -(cy / 2f - (39f + c.gap)) * e;   // status bars end up `gap` px under the crosshair
        float s = 1f + (c.hudScale - 1f) * e;

        graphics.pose().pushMatrix();
        graphics.pose().translate(cx + c.hudOffsetX * e, cy + offY);
        graphics.pose().scale(s, s);
        graphics.pose().translate(-cx, -cy);
        return true;
    }
}
