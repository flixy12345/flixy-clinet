package com.example.auroramod;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MappableRingBuffer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.Level;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

import java.util.OptionalDouble;
import java.util.OptionalInt;

/**
 * Night-sky styles drawn on a dome around the camera: Aurora, Iris, Galaxy, Velvet, Silver.
 * Uses two custom render pipelines (additive and alpha), depth-tested with no depth write,
 * so terrain and nearby objects correctly cover the sky.
 */
public final class AuroraRenderer {
    private static RenderPipeline makePipeline(String name, BlendFunction blend) {
        return RenderPipelines.register(
                RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
                        .withLocation(Identifier.fromNamespaceAndPath(AuroraMod.MOD_ID, "pipeline/" + name))
                        .withVertexFormat(DefaultVertexFormat.POSITION_COLOR, VertexFormat.Mode.QUADS)
                        .withBlend(blend)
                        .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                        .withDepthWrite(false)
                        .withCull(false)
                        .build());
    }

    private static final RenderPipeline PIPE_ADD = makePipeline("aurora_add", BlendFunction.ADDITIVE);      // colors premultiplied
    private static final RenderPipeline PIPE_ALPHA = makePipeline("aurora_alpha", BlendFunction.TRANSLUCENT);

    private static final MappableRingBuffer[] rings = new MappableRingBuffer[3];

    private static final Vector4f COLOR_MODULATOR = new Vector4f(1f, 1f, 1f, 1f);
    private static final Vector3f MODEL_OFFSET = new Vector3f();
    private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();

    private static final float TAU = (float) (Math.PI * 2.0);
    private static final float RAD = (float) (Math.PI / 180.0);
    private static final int[][] QUALITY = {{64, 12}, {96, 18}, {128, 24}, {192, 32}};

    private static final int MAX_N = (192 + 1) * (32 + 1);
    private static final float[] px = new float[MAX_N], py = new float[MAX_N], pz = new float[MAX_N];
    private static final float[] cr = new float[MAX_N], cg = new float[MAX_N], cb = new float[MAX_N], ca = new float[MAX_N];

    private static final float[] KEY_POS = {0f, 0.3f, 0.65f, 1f};
    private static final float[][][] PRESETS = {
            {{0.25f, 1f, 0.45f}, {0.10f, 0.95f, 0.70f}, {0.35f, 0.50f, 1f}, {0.80f, 0.25f, 0.85f}}, // Classic
            {{0.30f, 1f, 0.50f}, {0.10f, 1f, 0.80f}, {0.10f, 0.70f, 1f}, {0.20f, 0.40f, 1f}},       // Polar
            {{0.50f, 0.40f, 1f}, {0.70f, 0.30f, 1f}, {0.95f, 0.35f, 0.90f}, {1f, 0.50f, 0.80f}},     // Violet
            {{1f, 0.25f, 0.30f}, {1f, 0.30f, 0.50f}, {0.85f, 0.30f, 0.80f}, {0.50f, 0.20f, 0.90f}},  // Crimson
            {{1f, 0.70f, 0.20f}, {1f, 0.45f, 0.35f}, {0.95f, 0.30f, 0.60f}, {0.50f, 0.25f, 0.80f}},  // Sunset
            {{0.90f, 1f, 1f}, {0.50f, 0.95f, 1f}, {0.35f, 0.70f, 1f}, {0.40f, 0.50f, 1f}},           // Ice
            {{1f, 0.30f, 0.30f}, {1f, 0.90f, 0.30f}, {0.30f, 1f, 0.50f}, {0.40f, 0.50f, 1f}}         // Rainbow base
    };
    private static final float[][] IRIS = {
            {0.96f, 0.98f, 1.00f}, {0.86f, 0.90f, 0.96f}, {0.70f, 0.76f, 0.86f}, {0.55f, 0.62f, 0.75f}};
    private static final int RAINBOW = 6, CUSTOM = 7;

    // tint color + alpha per sky style: Aurora, Iris, Galaxy, Velvet, Silver
    private static final float[][] TINT = {
            {0f, 0f, 0f, 0f},
            {0.10f, 0.11f, 0.13f, 0.50f},
            {0.22f, 0.04f, 0.36f, 0.62f},
            {0.13f, 0.02f, 0.22f, 0.75f},
            {0.06f, 0.06f, 0.07f, 0.80f}};

    // per-frame state
    private static long lastMs = System.currentTimeMillis();
    private static float animTime = 0f, hueTime = 0f;
    private static float[][] activeKeys = PRESETS[0];
    private static boolean activeRainbow = false;
    private static float activeHue = 0f, activeSat = 1f;
    private static final float[] tmp = new float[3];
    private static float radius = 160f;

    private AuroraRenderer() {}

    // ---------- helpers ----------

    private static float clamp(float v, float lo, float hi) { return v < lo ? lo : Math.min(v, hi); }
    private static float sin(float v) { return (float) Math.sin(v); }
    private static float cos(float v) { return (float) Math.cos(v); }
    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }

    private static float smooth(float a, float b, float x) {
        float t = clamp((x - a) / (b - a), 0f, 1f);
        return t * t * (3f - 2f * t);
    }

    private static float envelope(float theta0, float t, float lo, float hi) {
        float e1 = 0.5f + 0.5f * sin(2 * theta0 + 0.11f * t);
        float e2 = 0.5f + 0.5f * sin(3 * theta0 - 0.07f * t + 1.3f);
        return smooth(lo, hi, e1 * 0.6f + e2 * 0.5f);
    }

    /** Sun height: 1 at noon, -1 at midnight (same curve vanilla has always used). */
    private static float sunHeight(ClientLevel level) {
        long dayTime = level.getDayTime();
        float frac = (float) (((dayTime % 24000L) + 24000L) % 24000L) / 24000f;
        float d = frac - 0.25f;
        d -= (float) Math.floor(d);
        float e = 0.5f - cos(d * (float) Math.PI) / 2f;
        float angle = d + (e - d) / 3f;
        return cos(angle * TAU);
    }

    private static void colorAt(float h, float theta0, float[] out) {
        int k = 0;
        while (k < 2 && h > KEY_POS[k + 1]) k++;
        float u = clamp((h - KEY_POS[k]) / (KEY_POS[k + 1] - KEY_POS[k]), 0f, 1f);
        float[] a = activeKeys[k], b = activeKeys[k + 1];
        float r = lerp(a[0], b[0], u), g = lerp(a[1], b[1], u), bl = lerp(a[2], b[2], u);
        float hue = activeHue + (activeRainbow ? theta0 / TAU * 360f : 0f);
        adjust(r, g, bl, hue, activeSat, out);
    }

    /** Rotate hue (degrees) and scale saturation of an RGB color. */
    private static void adjust(float r, float g, float b, float hueDeg, float sat, float[] out) {
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), d = max - min;
        float h;
        if (d < 1e-5f) h = 0f;
        else if (max == r) h = ((g - b) / d) % 6f;
        else if (max == g) h = (b - r) / d + 2f;
        else h = (r - g) / d + 4f;
        h = h * 60f + hueDeg;
        h = ((h % 360f) + 360f) % 360f;
        float s = max <= 0f ? 0f : clamp(d / max * sat, 0f, 1f);
        float v = max;
        float cc = v * s, hp = h / 60f;
        float x = cc * (1f - Math.abs(hp % 2f - 1f)), m = v - cc;
        float r1, g1, b1;
        switch ((int) hp) {
            case 0:  r1 = cc; g1 = x;  b1 = 0;  break;
            case 1:  r1 = x;  g1 = cc; b1 = 0;  break;
            case 2:  r1 = 0;  g1 = cc; b1 = x;  break;
            case 3:  r1 = 0;  g1 = x;  b1 = cc; break;
            case 4:  r1 = x;  g1 = 0;  b1 = cc; break;
            default: r1 = cc; g1 = 0;  b1 = x;  break;
        }
        out[0] = r1 + m; out[1] = g1 + m; out[2] = b1 + m;
    }

    // ---------- main entry ----------

    public static void render(WorldRenderContext context) {
        AuroraConfig c = AuroraConfig.get();
        if (!c.auroraEnabled) return;

        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null || mc.player == null) return;

        // advance animation clocks (accumulated, so changing speed never causes jumps)
        long now = System.currentTimeMillis();
        float dt = Math.min((now - lastMs) / 1000f, 0.1f);
        lastMs = now;
        animTime += dt * c.speed;
        hueTime += dt * c.colorCycle * 30f;

        if (level.dimension() != Level.OVERWORLD) return;
        if (mc.player.isUnderWater()) return;

        float rain = level.getRainLevel(1.0f);
        float night = smooth(-0.05f, 0.35f, -sunHeight(level));
        float vis = Math.max(night, c.dayVisibility);
        float strength = vis * (1f - c.rainDimming * rain) * c.intensity;
        float tintVis = vis * (1f - 0.5f * rain) * c.skyTint;
        if (strength <= 0.01f && tintVis <= 0.01f) return;

        // Put the dome just beyond the terrain so near terrain hides it but the sky doesn't.
        radius = Math.max(60f, mc.options.getEffectiveRenderDistance() * 16f * 1.8f);

        SkyScene.init();
        int style = Math.floorMod(c.skyStyle, AuroraConfig.SKY_NAMES.length);
        Matrix4fc pose = context.matrices().last().pose();
        float t = animTime;
        float rot = animTime * 0.004f;
        float flick = 1f + 0.12f * c.flicker * (sin(animTime * 0.8f) - 1f);

        // ---- pass 1: sky tint (alpha) ----
        SkyBatch b = new SkyBatch(PIPE_ALPHA, pose, false, radius);
        if (style != 0 && tintVis > 0.01f) {
            float[] tc = TINT[style];
            SkyScene.tint(b, tc[0], tc[1], tc[2], tc[3] * tintVis);
        }
        flush(mc, b, 0);

        // ---- pass 2: glowing things (additive) ----
        b = new SkyBatch(PIPE_ADD, pose, true, radius);
        if (strength > 0.01f) {
            switch (style) {
                case 0:
                case 1:
                    setColors(c, style);
                    curtains(b, c, style, strength, flick);
                    if (style == 1) SkyScene.stars(b, Math.round(500 * c.starDensity), t, strength, rot);
                    break;
                case 2:
                    SkyScene.nebula(b, t, strength * c.nebula, rot);
                    SkyScene.stars(b, Math.round(2600 * c.starDensity), t, strength, rot);
                    if (c.blackHole) SkyScene.blackHoleLight(b, t, strength);
                    break;
                case 3:
                    SkyScene.stars(b, Math.round(450 * c.starDensity), t, strength, rot);
                    SkyScene.lightning(b, t, strength, c.lightning,
                            0.55f, 0.15f, 0.95f, 0.92f, 0.78f, 1.0f);
                    break;
                default:
                    SkyScene.stars(b, Math.round(300 * c.starDensity), t, strength, rot);
                    SkyScene.lightning(b, t, strength, c.lightning,
                            0.70f, 0.75f, 0.85f, 1.0f, 1.0f, 1.0f);
                    break;
            }
        }
        flush(mc, b, 1);

        // ---- pass 3: solid objects (alpha): ringed planet + black hole disc ----
        if (style == 2 && tintVis > 0.01f && (c.planet || c.blackHole)) {
            b = new SkyBatch(PIPE_ALPHA, pose, false, radius);
            if (c.planet) {
                SkyScene.planetRing(b, 0, tintVis);
                SkyScene.planetBody(b, tintVis);
                SkyScene.planetRing(b, 1, tintVis);
            }
            if (c.blackHole) SkyScene.blackHoleDisc(b, tintVis);
            flush(mc, b, 2);
        }
    }

    private static void setColors(AuroraConfig c, int style) {
        if (style == 1) {
            activeKeys = IRIS;
            activeRainbow = false;
            activeHue = 0f;
            activeSat = 1f;
            return;
        }
        if (c.preset == CUSTOM) {
            activeKeys = new float[][]{c.customBottom, c.customMiddle, c.customMiddle, c.customTop};
        } else {
            activeKeys = PRESETS[Math.min(c.preset, PRESETS.length - 1)];
        }
        activeRainbow = c.preset == RAINBOW;
        activeHue = c.hueShift + hueTime;
        activeSat = c.saturation;
    }

    // ---------- aurora curtains + horizon glow ----------

    private static void curtains(SkyBatch b, AuroraConfig c, int style, float strength, float flick) {
        float coverage = style == 1 ? 0.9f : c.coverage;
        float falloff = style == 1 ? 1.0f : c.falloff;
        float rayDensity = style == 1 ? c.rayDensity * 1.3f : c.rayDensity;
        float glow = style == 1 ? c.horizonGlow * 0.6f : c.horizonGlow;

        float lo = 0.9f - coverage;
        float hi = lo + 0.65f;
        float rot = c.rotation * RAD;
        float base = c.baseElevation * RAD;
        float top = Math.max(c.topElevation, c.baseElevation + 5f) * RAD;
        int f1 = Math.max(1, Math.round(47 * rayDensity));
        int f2 = Math.max(1, Math.round(113 * rayDensity));
        float wave = c.waves;
        float t = animTime;

        int seg = QUALITY[c.quality][0], rows = QUALITY[c.quality][1];
        int rows1 = rows + 1;

        for (int i = 0; i <= seg; i++) {
            float theta0 = (float) i / seg * TAU;
            float envelope = envelope(theta0, t, lo, hi);

            float rawRay = 0.65f + 0.35f * sin(f1 * theta0 + 1.7f * sin(5 * theta0 + 0.4f * t) + 0.9f * t);
            rawRay *= 0.8f + 0.2f * sin(f2 * theta0 - 1.3f * t);
            float ray = Math.max(0f, 1f + c.shimmer * (rawRay - 1f));

            for (int j = 0; j <= rows; j++) {
                float h = (float) j / rows;
                int k = i * rows1 + j;

                float elev = lerp(base, top, h) + 4f * RAD * wave * sin(3 * theta0 + 0.25f * t) * (1f - h);
                float th = theta0 + rot + wave * (
                        0.07f * sin(4 * theta0 + 0.35f * t + h * 2.5f)
                      + 0.03f * sin(9 * theta0 - 0.5f * t + h * 4f));

                float ce = cos(elev);
                px[k] = ce * cos(th);
                py[k] = sin(elev);
                pz[k] = ce * sin(th);

                colorAt(h, theta0, tmp);
                cr[k] = tmp[0]; cg[k] = tmp[1]; cb[k] = tmp[2];

                float vertical = smooth(0f, 0.05f, h) * (float) Math.pow(1f - h, falloff) * (1f - 0.4f * h);
                ca[k] = Math.min(1f, strength * envelope * ray * flick * vertical * 0.6f);
            }
        }

        for (int i = 0; i < seg; i++) {
            for (int j = 0; j < rows; j++) {
                int a = i * rows1 + j;
                int bb = a + 1;
                int cc = (i + 1) * rows1 + j + 1;
                int d = (i + 1) * rows1 + j;
                b.v(px[a], py[a], pz[a], cr[a], cg[a], cb[a], ca[a]);
                b.v(px[bb], py[bb], pz[bb], cr[bb], cg[bb], cb[bb], ca[bb]);
                b.v(px[cc], py[cc], pz[cc], cr[cc], cg[cc], cb[cc], ca[cc]);
                b.v(px[d], py[d], pz[d], cr[d], cg[d], cb[d], ca[d]);
            }
        }

        if (glow > 0.01f) {
            int gs = 64, gr = 6;
            for (int i = 0; i < gs; i++) {
                for (int j = 0; j < gr; j++) {
                    glowVertex(b, i, j, gs, gr, strength, flick, lo, hi, rot, glow);
                    glowVertex(b, i, j + 1, gs, gr, strength, flick, lo, hi, rot, glow);
                    glowVertex(b, i + 1, j + 1, gs, gr, strength, flick, lo, hi, rot, glow);
                    glowVertex(b, i + 1, j, gs, gr, strength, flick, lo, hi, rot, glow);
                }
            }
        }
    }

    private static void glowVertex(SkyBatch b, int i, int j, int gs, int gr,
                                   float strength, float flick, float lo, float hi, float rot, float glow) {
        float theta0 = (float) i / gs * TAU;
        float v = (float) j / gr;
        float elev = lerp(-3f * RAD, 32f * RAD, v);
        float ce = cos(elev);
        float th = theta0 + rot;

        float env = 0.35f + 0.65f * envelope(theta0, animTime, lo, hi);
        colorAt(0.05f, theta0, tmp);
        float a = Math.min(1f, strength * glow * env * flick * (1f - v) * (1f - v) * 0.45f);
        b.v(ce * cos(th), sin(elev), ce * sin(th), tmp[0], tmp[1], tmp[2], a);
    }

    // ---------- drawing (follows the Fabric 1.21.11 custom-pipeline guide) ----------

    private static void flush(Minecraft client, SkyBatch batch, int layer) {
        if (batch.vertices == 0) return;
        MeshData builtBuffer = batch.buf.build();
        if (builtBuffer == null) return;
        MeshData.DrawState drawParameters = builtBuffer.drawState();
        VertexFormat format = drawParameters.format();

        GpuBuffer vertices = upload(layer, drawParameters, format, builtBuffer);
        draw(client, batch.pipeline, builtBuffer, drawParameters, vertices);

        // Rotate the vertex buffer so we are less likely to use buffers that the GPU is using
        rings[layer].rotate();
    }

    private static GpuBuffer upload(int layer, MeshData.DrawState drawParameters, VertexFormat format, MeshData builtBuffer) {
        int vertexBufferSize = drawParameters.vertexCount() * format.getVertexSize();

        MappableRingBuffer ring = rings[layer];
        if (ring == null || ring.size() < vertexBufferSize) {
            if (ring != null) {
                ring.close();
            }
            ring = new MappableRingBuffer(() -> AuroraMod.MOD_ID + " sky vertices",
                    GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_MAP_WRITE, Math.max(vertexBufferSize, 1 << 19));
            rings[layer] = ring;
        }

        CommandEncoder commandEncoder = RenderSystem.getDevice().createCommandEncoder();
        try (GpuBuffer.MappedView mappedView = commandEncoder.mapBuffer(
                ring.currentBuffer().slice(0, builtBuffer.vertexBuffer().remaining()), false, true)) {
            MemoryUtil.memCopy(builtBuffer.vertexBuffer(), mappedView.data());
        }

        return ring.currentBuffer();
    }

    private static void draw(Minecraft client, RenderPipeline pipeline, MeshData builtBuffer,
                             MeshData.DrawState drawParameters, GpuBuffer vertices) {
        // Quads use the shared sequential index buffer (no sorting needed)
        RenderSystem.AutoStorageIndexBuffer shapeIndexBuffer = RenderSystem.getSequentialBuffer(pipeline.getVertexFormatMode());
        GpuBuffer indices = shapeIndexBuffer.getBuffer(drawParameters.indexCount());
        VertexFormat.IndexType indexType = shapeIndexBuffer.type();

        GpuBufferSlice dynamicTransforms = RenderSystem.getDynamicUniforms()
                .writeTransform(RenderSystem.getModelViewMatrix(), COLOR_MODULATOR, MODEL_OFFSET, TEXTURE_MATRIX);

        try (RenderPass renderPass = RenderSystem.getDevice()
                .createCommandEncoder()
                .createRenderPass(() -> AuroraMod.MOD_ID + " sky",
                        client.getMainRenderTarget().getColorTextureView(), OptionalInt.empty(),
                        client.getMainRenderTarget().getDepthTextureView(), OptionalDouble.empty())) {
            renderPass.setPipeline(pipeline);

            RenderSystem.bindDefaultUniforms(renderPass);
            renderPass.setUniform("DynamicTransforms", dynamicTransforms);

            renderPass.setVertexBuffer(0, vertices);
            renderPass.setIndexBuffer(indices, indexType);

            renderPass.drawIndexed(0, 0, drawParameters.indexCount(), 1);
        }

        builtBuffer.close();
    }

    public static void close() {
        SkyBatch.ALLOCATOR.close();
        for (int i = 0; i < rings.length; i++) {
            if (rings[i] != null) {
                rings[i].close();
                rings[i] = null;
            }
        }
    }
}
