package com.example.auroramod;

import com.example.auroramod.gui.AuroraSettingsScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** The money tracker bubble: big session number, a day-trading style line chart, then clean rows. */
public final class MoneyHud {
    private static final int HEADER = 0, BIG = 1, SUB = 2, CHART = 3, DIVIDER = 4, KV = 5, RECENT = 6;
    private static final int CHART_H = 34;

    private record Row(int kind, String left, String right, int color) {}

    private MoneyHud() {}

    private static int rowHeight(int kind) {
        switch (kind) {
            case HEADER:  return 10;
            case BIG:     return 16;
            case SUB:     return 10;
            case CHART:   return CHART_H + 4;
            case DIVIDER: return 5;
            case KV:      return 10;
            default:      return 9;
        }
    }

    /** Fake data so you can style the bubble from the settings screen before you are on the server. */
    public static List<double[]> demoPoints() {
        List<double[]> l = new ArrayList<>();
        long base = System.currentTimeMillis() - 60L * 60_000L;
        for (int i = 0; i < 48; i++) {
            double v = 2_265_000 + 70_000 * Math.sin(i * 0.33) + i * 4_200 - 25_000 * Math.sin(i * 0.9);
            l.add(new double[]{base + i * 75_000L, v});
        }
        return l;
    }

    public static void render(GuiGraphics g) {
        AuroraConfig c = AuroraConfig.get();
        Minecraft mc = Minecraft.getInstance();
        if (!c.moneyHud || mc.options.hideGui) return;

        double bal, start, gained, lost, elapsed, baseline;
        List<Double> recent;
        List<double[]> pts;
        if (MoneyTracker.isActive()) {
            bal = MoneyTracker.balance();
            start = MoneyTracker.startBalance();
            gained = MoneyTracker.gained();
            lost = MoneyTracker.lost();
            elapsed = MoneyTracker.elapsedSeconds();
            recent = MoneyTracker.recent();
            pts = MoneyTracker.chartPoints(c.chartRange);
            baseline = MoneyTracker.chartBaseline(c.chartRange, pts);
        } else if (mc.screen instanceof AuroraSettingsScreen) {
            pts = demoPoints();
            start = pts.get(0)[1];
            baseline = start;
            bal = pts.get(pts.size() - 1)[1];
            gained = 185_000; lost = 40_000; elapsed = 1520;
            recent = new ArrayList<>(Arrays.asList(12_500.0, -5_000.0, 80_000.0));
        } else {
            return;
        }

        boolean cp = c.moneyCompact;
        double net = bal - start;
        long secs = (long) elapsed;
        String time = String.format("%02d:%02d:%02d", secs / 3600, (secs / 60) % 60, secs % 60);

        List<Row> rows = new ArrayList<>();
        rows.add(new Row(HEADER, "TRACKER", c.showTime ? time : "", HudStyle.GREY));
        rows.add(new Row(BIG, MoneyTracker.signed(net, cp), "", net >= 0 ? HudStyle.GREEN : HudStyle.RED));
        rows.add(new Row(SUB, "Started with $" + MoneyTracker.format(start, cp), "", HudStyle.GREY));
        if (c.showChart) rows.add(new Row(CHART, "", "", 0));
        rows.add(new Row(DIVIDER, "", "", 0));
        rows.add(new Row(KV, "Balance", "$" + MoneyTracker.format(bal, cp), HudStyle.GOLD));
        if (c.showEarnedLost) {
            rows.add(new Row(KV, "Earned", MoneyTracker.signed(gained, cp), HudStyle.GREEN));
            rows.add(new Row(KV, "Lost", "-$" + MoneyTracker.format(lost, cp), HudStyle.RED));
        }
        if (c.showRate) {
            if (elapsed >= 30) {
                double perHour = net / (elapsed / 3600.0);
                rows.add(new Row(KV, "Per hour", MoneyTracker.signed(perHour, cp) + "/h",
                        perHour >= 0 ? HudStyle.GREEN : HudStyle.RED));
            } else {
                rows.add(new Row(KV, "Per hour", "--", HudStyle.GREY));
            }
        }
        if (c.showLifetime) {
            double lt = c.lifetimeGained - c.lifetimeLost;
            rows.add(new Row(KV, "All-time", MoneyTracker.signed(lt, cp), lt >= 0 ? HudStyle.GREEN : HudStyle.RED));
        }
        int n = Math.min(c.recentCount, recent.size());
        for (int i = 0; i < n; i++) {
            double d = recent.get(i);
            rows.add(new Row(RECENT, MoneyTracker.signed(d, cp), "", d >= 0 ? HudStyle.GREEN : HudStyle.RED));
        }

        Font font = mc.font;

        // size
        int w = 132;
        int h = 12;
        for (Row r : rows) {
            h += rowHeight(r.kind());
            int need;
            switch (r.kind()) {
                case HEADER: need = HudStyle.width(font, r.left(), 0.7f, true) + 14 + HudStyle.width(font, r.right(), 0.7f, false); break;
                case BIG:    need = HudStyle.width(font, r.left(), 1.5f, true); break;
                case SUB:    need = HudStyle.width(font, r.left(), 0.75f, false); break;
                case KV:     need = HudStyle.width(font, r.left(), 0.8f, false) + 14 + HudStyle.width(font, r.right(), 0.8f, true); break;
                case RECENT: need = HudStyle.width(font, r.left(), 0.8f, false) + 4; break;
                default:     need = 0; break;
            }
            w = Math.max(w, need + 12);
        }

        // position
        float s = c.moneyScale;
        float boxW = w * s, boxH = h * s;
        int sw = mc.getWindow().getGuiScaledWidth(), sh = mc.getWindow().getGuiScaledHeight();
        boolean right = c.moneyAnchor == 1 || c.moneyAnchor == 3 || c.moneyAnchor == 4;
        boolean bottom = c.moneyAnchor == 2 || c.moneyAnchor == 3;
        boolean middle = c.moneyAnchor == 4 || c.moneyAnchor == 5;
        float x = right ? sw - boxW - c.moneyX : c.moneyX;
        float y = middle ? (sh - boxH) / 2f - c.moneyY : (bottom ? sh - boxH - c.moneyY : c.moneyY);

        g.pose().pushMatrix();
        g.pose().translate(x, y);
        g.pose().scale(s, s);

        int bgAlpha = Math.round(Math.max(0f, Math.min(1f, c.moneyBg)) * 255f * 0.95f);
        HudStyle.panel(g, 0, 0, w, h, bgAlpha);

        float cy = 6;
        for (Row r : rows) {
            switch (r.kind()) {
                case HEADER:
                    HudStyle.text(g, font, r.left(), 8, cy + 1, HudStyle.GREY, 0.7f, true);
                    if (!r.right().isEmpty()) {
                        HudStyle.text(g, font, r.right(), w - 8 - HudStyle.width(font, r.right(), 0.7f, false),
                                cy + 1, HudStyle.GREY, 0.7f, false);
                    }
                    break;
                case BIG:
                    HudStyle.text(g, font, r.left(), 8, cy, r.color(), 1.5f, true);
                    break;
                case SUB:
                    HudStyle.text(g, font, r.left(), 8, cy + 1, HudStyle.GREY, 0.75f, false);
                    break;
                case CHART:
                    HudStyle.roundRect(g, 6, (int) cy, w - 12, CHART_H + 2, 4, 0x55000000);
                    ChartRenderer.draw(g, font, 7, (int) cy + 1, w - 14, CHART_H, pts, baseline, false, cp);
                    break;
                case DIVIDER:
                    g.fill(8, (int) cy + 2, w - 8, (int) cy + 3, HudStyle.DIVIDER);
                    break;
                case KV:
                    HudStyle.text(g, font, r.left(), 8, cy + 1, HudStyle.GREY, 0.8f, false);
                    HudStyle.text(g, font, r.right(), w - 8 - HudStyle.width(font, r.right(), 0.8f, true),
                            cy + 1, r.color(), 0.8f, true);
                    break;
                default:
                    HudStyle.text(g, font, r.left(), 12, cy + 1, r.color(), 0.8f, false);
                    break;
            }
            cy += rowHeight(r.kind());
        }

        g.pose().popMatrix();
    }
}
